package com.example.gezuzm.imagencorporativa.pojo;

import com.example.gezuzm.imagencorporativa.R;

/**
 * Created by mauricio on 21/08/16.
 */
public class Mascota {

    private String id;     // modelo VISTA-PRESENTADOR
    private String urlImgMascota;
    //private int imgIconoLike;
    //private int imgIconoNoLike;
    private String nombreCompleto;
    private int noLike = 0;


    // para modelo VISTA-PRESENTADOR
    public Mascota(String urlImgMascota, String nombreCompleto, int noLike)
    {
        this.urlImgMascota = urlImgMascota;
       // this.imgIconoLike = R.drawable.hueso_nosilueta;
        //this.imgIconoNoLike = R.drawable.hueso_silueta ;
        this.nombreCompleto = nombreCompleto;
        this.noLike = noLike;
    }

    public Mascota() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUrlImgMascota() {
        return urlImgMascota;
    }

    public void setUrlImgMascota(String urlImgMascota) {
        this.urlImgMascota = urlImgMascota;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public int getNoLike() {
        return noLike;
    }

    public void setNoLike(int noLike) {
        this.noLike = noLike;
    }


/*
        public Mascota()
        {
        this.imgMascota = urlImgMascota;
        this.imgIconoLike = R.drawable.hueso_nosilueta;
        this.imgIconoNoLike = R.drawable.hueso_silueta ;
        this.nombreMascota = nombreMascota;
        this.noLike = 0;
    }

    public Mascota(int imgMascota, int noLike, int imgIconoNoLike )
    {
        this.imgMascota = imgMascota;
        //this.imgIconoLike = R.drawable.hueso_nosilueta;
        this.imgIconoNoLike = imgIconoNoLike ;
       // this.nombreMascota = nombreMascota;
        this.noLike = noLike;
    }*/

    /*
    public int getFotoMascota() {
        return imgMascota;
    }

    public void setFotoMascota(int imgMascota) {
        this.imgMascota = imgMascota;
    }

    public int getImgIconoLike() {
        return imgIconoLike;
    }

    public void setImgIconoLike(int imgIconoLike) {
        this.imgIconoLike = imgIconoLike;
    }

    public int getImgIconoNoLike() {
        return imgIconoNoLike;
    }

    public void setImgIconoNoLike(int imgIconoNoLike) {
        this.imgIconoNoLike = imgIconoNoLike;
    }

    public String getNombreMascota() {
        return nombreMascota;
    }

    public void setNombreMascota(String nombreMascota) {
        this.nombreMascota = nombreMascota;
    }

    public int getNoLike() {
        return noLike;
    }

    public void setNoLike(int noLike) {
        this.noLike = noLike;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }*/
}
