package com.example.gezuzm.imagencorporativa;

/**
 * Created by mauricio on 29/08/16.
 */
public class Config {

        public static final String EMAIL ="emailpruebas123456789@gmail.com";
        public static final String PASSWORD ="abcdef12345";

}
