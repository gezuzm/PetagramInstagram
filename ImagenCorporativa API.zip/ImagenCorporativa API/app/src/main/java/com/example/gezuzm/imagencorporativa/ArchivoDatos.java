package com.example.gezuzm.imagencorporativa;

import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by mauricio on 20/09/16.
 */
public class ArchivoDatos extends AppCompatActivity {


    public String cargarUsuario() {

        String usuario = "";

        try{
            //FileInputStream fis =  openFileInput("usuario.txt");

            FileInputStream fis = openFileInput("usuario.txt");
            InputStreamReader isr = new InputStreamReader(fis);

            char[] inputBuffer = new char[100];

            int charRead;
            while((charRead = isr.read(inputBuffer)) > 0){
                // Convertimos los char a String
                String readString = String.copyValueOf(inputBuffer, 0, charRead);
                usuario += readString;

                inputBuffer = new char[100];
            }

            // Establecemos en el EditText el texto que hemos leido
            ///textBox.setText(s);

            // Mostramos un Toast con el proceso completado
            //Toast.makeText(context, "Usuario: " + usuario, Toast.LENGTH_SHORT).show();

            isr.close();
        }catch (IOException ex){
            usuario= "";
            ex.printStackTrace();
        }

        return usuario;
    }

}
