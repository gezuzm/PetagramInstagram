package com.example.gezuzm.imagencorporativa;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.gezuzm.imagencorporativa.pojo.Mascota;
import com.example.gezuzm.imagencorporativa.presentador.RecyclerViewFragmentPresenter;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class ConfigurarCuenta extends AppCompatActivity {

    private EditText etUsuario;
    private Button btnGuardar;

 //   Activity activity;                  // tambien es necesaria una ACTIVIDAD

    // 4.- crear el constructor
   /* public ConfigurarCuenta(Activity activity){

        this.activity = activity;
    }
*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configurar_cuenta);

        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);

        etUsuario = (EditText) findViewById(R.id.etUsuario);
        btnGuardar = (Button) findViewById(R.id.btnGuardar);

        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String usuario = etUsuario.getText().toString();

                try{

                    FileOutputStream fos = openFileOutput("usuario.txt", MODE_PRIVATE);
                    OutputStreamWriter osw = new OutputStreamWriter(fos);

                    // Escribimos el String en el archivo
                    osw.write(usuario);
                    osw.flush();
                    osw.close();

                    // Mostramos que se ha guardado
                    Toast.makeText(getBaseContext(), "Guardado", Toast.LENGTH_SHORT).show();

                    etUsuario.setText("");
                }
                catch (IOException ex)
                {
                    ex.printStackTrace();
                }
            }
        });

    }
}
