package com.example.gezuzm.imagencorporativa.restApi;


import com.example.gezuzm.imagencorporativa.ArchivoDatos;
import com.example.gezuzm.imagencorporativa.restApi.model.MascotaResponse;

import retrofit2.Call;
import retrofit2.http.GET;


/**
 * Created by mauricio on 19/09/16.
 */
public interface IEndpointsApi {


    @GET(ConstantesRestApi.URL_GET_RECENT_MEDIA_USER)
    Call<MascotaResponse> getRecentMedia();



    @GET(ConstantesRestApi.URL_SEARCH_ID_USER)
    Call<MascotaResponse> getIdUsuario();
}
